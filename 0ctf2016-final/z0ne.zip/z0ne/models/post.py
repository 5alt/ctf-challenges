import mysql

class post:
	def __init__(self):
		self.mysql = mysql.mysql()

	def count(self):
		sql = "SELECT COUNT(*) as total FROM posts"
		return self.mysql.fetchOne(sql)['total']
		
	def add(self, title, content, author):
		sql = "INSERT INTO posts(title, content, author) VALUES(%s, %s, %s)"
		self.mysql.execute(sql, [title, content, author])
		return True

	def edit(self, pid, title, content):
		sql = "UPDATE posts SET title=%s, content=%s WHERE pid=%s"
		self.mysql.execute(sql, (title, content, int(pid)))
		return True

	def delete(self, pid):
		sql = "DELETE FROM posts WHERE pid=%d"%int(pid)
		self.mysql.execute(sql)
		return True

	def list(self, skip, limit):
		sql = "SELECT * FROM posts ORDER BY pid DESC LIMIT %d,%d"%(skip, limit)
		return self.mysql.fetchAll(sql)

	def get(self, pid):
		sql = "SELECT* FROM posts WHERE pid=%d"%(int(pid))
		return self.mysql.fetchOne(sql)