# -*- coding: utf-8 -*-
#!/usr/bin/env python
import os
import rsa
import mysql

class flag:
	def __init__(self):
		self.mysql = mysql.mysql()
		self.pubkey = None
		basedir = os.path.abspath(os.path.dirname(__file__))
		secret_file = os.path.join(basedir, '../public.pem')
		with open(secret_file, 'r') as publickfile:
			p = publickfile.read()
			self.pubkey = rsa.PublicKey.load_pkcs1(p)

	def check_flag(self, teamid, nonce, signature):
		if rsa.verify(teamid+nonce, signature.decode('hex'), self.pubkey):
			return self.flag()
		else:
			return 'sign error'

	def flag(self):
		sql = "SELECT flag FROM flag"
		return self.mysql.fetchOne(sql)['flag']