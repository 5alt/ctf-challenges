import mysql
from flask import session
import hashlib
import random, string
import subprocess

def md5(data):
	return hashlib.md5(data).hexdigest()

class user:
	def __init__(self):
		self.mysql = mysql.mysql()

	def login(self, email, password):
		if email.endswith('@5alt.me'):
			admin = 1
		else:
			admin = 0
		sql = "SELECT * FROM users WHERE email=%s AND password=%s AND active=1"
		res = self.mysql.fetchOne(sql, (email, md5(password)))
		if res:
			session['user'] = {'email': email, 'admin': admin}
			return True
		else:
			return False

	def reg(self, email, password):
		secret = ''.join([(string.ascii_letters+string.digits)[x] for x in random.sample(range(0,62),16)])
		subprocess.Popen("echo 'your secret code is: %s' | mail -s 'activate your account' %s"%(secret, email), shell=True)
		sql = "INSERT INTO `users`(email, password, secret) VALUES ('%s', '%s', '%s')"
		self.mysql.execute(sql%(email, md5(password), secret))
		return True

	def activate(self, email, secret):
		sql = "SELECT * FROM `users` WHERE email=%s AND secret=%s AND active=0"
		res = self.mysql.fetchOne(sql, (email, secret))
		if res:
			if email.endswith('@5alt.me'):
				admin = 1
			else:
				admin = 0
			session['user'] = {'email': email, 'admin': admin}
			sql = "UPDATE users SET active=1 WHERE email='%s'"
			self.mysql.execute(sql%email)
			return True
		else:
			return False

	def reset(self, email, password, newpwd):
		sql = "SELECT * FROM `users` WHERE email=%s AND password=%s"
		res = self.mysql.fetchOne(sql, (email, md5(password)))
		if res:
			sql = "UPDATE users SET password=md5('%s') WHERE email='%s'"
			self.mysql.execute(sql%(newpwd, email))
			return True
		else:
			return False

	def list(self):
		sql = "SELECT * FROM users"
		return self.mysql.fetchAll(sql)

	def delete(self, id):
		sql = "DELETE FROM users WHERE id=%d"
		self.mysql.execute(sql%id)
		return True

	def logout(self):
		return session.pop('user', None)