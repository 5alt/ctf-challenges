import os

DATABASE_HOST = 'localhost'
DATABASE_USER = 'z0ne'
DATABASE_PASSWORD = 'cRZobobLgPpSdwXf'
DATABASE_NAME = 'z0ne'

conn = None

SECRET_KEY = ""
basedir = os.path.abspath(os.path.dirname(__file__))
secret_file = os.path.join(basedir, '.secret')
if os.path.exists(secret_file):
    f = open(secret_file, 'r')
    SECRET_KEY = f.read().strip()
    f.close()
else:
    SECRET_KEY = os.urandom(24)
    f = open(secret_file, 'w')
    f.write(SECRET_KEY)
    f.close()

PER_PAGE = 10
BLOG_TITLE = "0Z0ne"
BLOG_DESCRIPTION = "a buggy zone"
DEBUG = True