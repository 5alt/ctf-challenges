#-*- coding:utf-8 -*-
import sys
reload(sys)
sys.setdefaultencoding('utf8')
from flask import Flask, render_template, render_template_string, abort, url_for, request, flash, session, redirect
import os, urllib

import pagination
from helper_functions import *

from models.user import user as userModel
from models.post import post as postModel
from models.flag import flag as flagModel

app = Flask('Z0ne', template_folder='/home/z0ne/templates', static_folder='/home/z0ne/static')

app.config.from_object('config')

@app.route('/', defaults={'page': 1})
@app.route('/page-<int:page>')
def index(page):
    skip = (page - 1) * int(app.config['PER_PAGE'])
    posts = postClass.list(skip, int(app.config['PER_PAGE']))
    count = postClass.count()
    pag = pagination.Pagination(page, app.config['PER_PAGE'], count)
    return render_template('index.html', posts=posts, pagination=pag, meta_title=app.config['BLOG_TITLE'])

@app.route('/post/<pid>')
def single_post(pid):
    post = postClass.get(int(pid))
    if not post:
        abort(404)
    return render_template('single_post.html', post=post, meta_title=app.config['BLOG_TITLE'] + '::' + post['title'])

@app.route('/newpost', methods=['GET', 'POST'])
@login_required()
def new_post():
    error = False
    error_type = 'validate'
    if request.method == 'POST':
        post_title = request.form.get('post-title').strip()
        post_full = request.form.get('post-full')

        if not post_title or not post_full:
            error = True
        else:
            if request.form.get('post-id'):
                if postClass.edit(request.form['post-id'], post_title, post_full):
                    flash('Post updated!', 'success')
                else:
                    flash('update error', 'error')
                return redirect(url_for('posts'))
            else:
                if not postClass.add(post_title, post_full, session['user']['email']):
                    error = True
                    error_type = 'post'
                    flash('add error', 'error')
                else:
                    flash('New post created!', 'success')
    return render_template('new_post.html',
                           meta_title='New post',
                           error=error,
                           error_type=error_type)

@app.route('/posts_list', defaults={'page': 1})
@app.route('/posts_list/page-<int:page>')
@login_required()
def posts(page):
    skip = (page - 1) * int(app.config['PER_PAGE'])
    posts = postClass.list(skip, int(app.config['PER_PAGE']))
    count = postClass.count()
    pag = pagination.Pagination(page, app.config['PER_PAGE'], count)
    if not posts:
        abort(404)
    return render_template('posts.html', posts=posts, pagination=pag, meta_title='Posts')

@app.route('/post_edit?id=<pid>')
@login_required()
def post_edit(pid):
    post = postClass.get(int(pid))
    if not post:
        flash('no such post', 'error')
        return redirect(url_for('posts'))

    return render_template('edit_post.html',
                           meta_title='Edit post::' + post['title'],
                           post=post,
                           error=False,
                           error_type=False)

@app.route('/post_delete?id=<pid>')
@login_required()
def post_del(pid):
    if postClass.count() > 1:
        if postClass.delete(int(pid)):
            flash('Post removed!', 'success')
        else:
            flash(response['error'], 'error')
    else:
        flash('Need to be at least one post..', 'error')
    return redirect(url_for('posts'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = False
    error_type = 'validate'
    if request.method == 'POST':
        username = request.form.get('login-username')
        password = request.form.get('login-password')
        if not username or not password:
            error = True
        else:
            if not userClass.login(username.lower().strip(), password):
                error = True
                error_type = 'login'
                flash('password is wrong or user is not activated', 'error')
            else:
                flash('You are logged in!', 'success')
                return redirect(url_for('posts'))
    else:
        if session.get('user'):
            return redirect(url_for('posts'))

    return render_template('login.html',
                           meta_title='Login',
                           error=error,
                           error_type=error_type)

@app.route('/logout')
def logout():
    if userClass.logout():
        flash('You are logged out!', 'success')
    return redirect(url_for('login'))

@app.route('/add_user')
def add_user():
    return render_template('add_user.html', meta_title='Reg')

@app.route('/save_user', methods=['POST'])
def save_user():
    post_data = {
        'email': request.form.get('user-email', None),
        'new_pass': request.form.get('user-new-password', None)
    }
    if not post_data['email'] or not post_data['new_pass']:
        flash('Username and Email are required..', 'error')
        return redirect(url_for('add_user'))
    else:
        if not userClass.reg(post_data['email'], post_data['new_pass']):
            flash(user['error'], 'error')
            return redirect(url_for('add_user'))
        else:
            message ='User added! Check your email and activate your account!'
            flash(message, 'success')
    return redirect(url_for('activate'))

@app.route('/activate', methods=['GET', 'POST'])
def activate():
    secret = request.form.get('secret', None)
    email = request.form.get('user-email', None)
    if secret:
        if userClass.activate(email, secret):
            flash('activate successfully', 'success')
        else:
            flash('bad secret', 'error')
        return redirect(url_for('posts'))
    else:
        return render_template('activate.html', meta_title='activate')

@app.route('/reset_password', methods=['GET', 'POST'])
@login_required()
def reset_password():
    if request.method == 'POST':
        new_pass = request.form.get('user-new-password', None)
        old_pass = request.form.get('user-old-password', None)
        email = session['user']['email']
        if userClass.reset(email, old_pass, new_pass):
            flash('reset password successfully', 'success')
        else:
            flash('old password wrong', 'error')
        return redirect(url_for('reset_password'))
    else:
        return render_template('reset.html', meta_title='reset')

@app.route('/users')
@login_required()
def users_list():
    users = userClass.list()
    if not users:
        abort(404)
    else:
        return render_template('users.html', users=users, meta_title='Users')

@app.route('/delete_user?id=<id>')
@login_required()
def delete_user(id):
    if session['user']['admin']:
        if not userClass.delete(int(id)):
            flash('failed', 'error')
        else:
            flash('User deleted!', 'success')
    else:
        flash('You should be admin!', 'error')
    return redirect(url_for('users_list'))

@app.route('/upload', methods=['GET', 'POST'])
@login_required()
def upload():
    if request.method == 'POST':
        path = request.form.get('path', None)
        if not path:
            abort(400)
        url = request.form.get('url', None)
        f = request.files.get('file', None)
        basedir = os.path.abspath(os.path.dirname(__file__))
        if f:
            dst = os.path.join(basedir, path, f.filename)
            f.save(dst)
            flash(dst, 'success')
        else:
            flash('upload error', 'error')
        return redirect(url_for('upload'))
    else:
        return render_template('upload.html', meta_title='Upload')

@app.route('/download', methods=['GET', 'POST'])
@login_required()
def download():
    path = request.args.get('path', None)
    if path:
        with open(path, 'r') as f:
            data = f.read()
        return data
    else:
        abort(400)

@app.route('/flag')
@login_required()
def flag():
    '''
    only admin can get the flag
    '''
    if session['user']['admin']:
        return flagClass.flag()
    else:
        return 'you should be admin'

@app.route('/check_flag')
def check_flag():
    '''
    checker will check the flag using a rsa signed request
    '''
    teamid = request.args.get('teamid', None)
    nonce = request.args.get('nonce', None)
    signature = request.args.get('signature', None)
    if teamid and nonce and signature:
        return flagClass.check_flag(teamid, nonce, signature)
    else:
        abort(400)


@app.before_request
def set_globals():
    app.jinja_env.globals['recent_posts'] = postClass.list(0, 10)

@app.errorhandler(404)
def page_not_found(error):
    return render_template('404.html', meta_title='404'), 404


@app.template_filter('formatdate')
def format_datetime_filter(input_value, format_="%a, %d %b %Y"):
    return input_value.strftime(format_)

app.jinja_env.globals['url_for_other_page'] = url_for_other_page
app.jinja_env.globals['meta_description'] = app.config['BLOG_DESCRIPTION']
postClass = postModel()
userClass = userModel()
flagClass = flagModel()

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=8080, debug=app.config['DEBUG'])