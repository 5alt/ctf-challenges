CREATE DATABASE z0ne;
USE z0ne;

CREATE TABLE `users` (
  `id` int(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `email` varchar(64) NOT NULL DEFAULT 'admin',
  `password` varchar(128) NOT NULL,
  `active` int(2) NOT NULL DEFAULT 0,
  `secret` varchar(128)
)DEFAULT CHARSET=utf8;

CREATE TABLE `posts`(
  `pid` int(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `title` varchar(256) NOT NULL,
  `content` TEXT NOT NULL,
  `author`varchar(64) NOT NULL
)DEFAULT CHARSET=utf8;

CREATE TABLE `flag` (
  `flag` varchar(256)
);

INSERT INTO `users`(email, password, active) VALUES ('root@5alt.me', md5('gsajdg765jh'), 1);
INSERT INTO `posts`(title, content, author) VALUES ('0CTF 2016 Final', 'Welcome to 0CTF 2016 Final!', 'root@5alt.me');
INSERT INTO `flag`(flag) VALUES ('0ctf{hello}');

CREATE USER 'z0ne'@'localhost' IDENTIFIED BY 'cRZobobLgPpSdwXf';
GRANT SELECT,INSERT,UPDATE,DELETE ON z0ne.users TO 'z0ne'@'localhost' IDENTIFIED BY 'cRZobobLgPpSdwXf';
GRANT SELECT,INSERT,UPDATE,DELETE ON z0ne.posts TO 'z0ne'@'localhost' IDENTIFIED BY 'cRZobobLgPpSdwXf';
GRANT SELECT ON z0ne.flag TO 'z0ne'@'localhost' IDENTIFIED BY 'cRZobobLgPpSdwXf';
