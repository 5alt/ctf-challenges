Hello guys, this is a web challenge called 'z0ne'.

To start your service:
/usr/local/openresty/nginx/sbin/nginx -c /usr/local/openresty/nginx/conf/nginx.conf
sudo -u z0ne python /home/z0ne/web.py

To stop your service:
sudo killall -u z0ne
/usr/local/openresty/nginx/sbin/nginx -s stop

No resource-based DoS is allowed.

The challenge will be changed later.
