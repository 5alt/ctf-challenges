import hashlib

for i in xrange(99999999):
	if hashlib.md5(str(i)).hexdigest()[:6] == 'e28f8d':
		print i
		break