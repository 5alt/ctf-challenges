var fs = require('fs');
var page = require('webpage').create();

url = 'https://ctf.0ops.sjtu.cn'

page.open(url, function(status) {
  var doc = page.evaluate(function() {
    return document.documentElement.innerHTML
  });
  try{
  	fs.write("file.txt", doc+"\n\n", 'a');	
  }catch{}
  
  phantom.exit();
});