import os
import hashlib
import shutil

blackchars = ['http://127.0.0.1:8080', '404 Not Found']

root = "./www_back1/"
for rt, dirs, files in os.walk(root):
	for f in files:
		#fname = os.path.splitext(f)
		f = root + f
		with open(f, 'r') as fp:
			data = fp.read()
		for i in blackchars:
			if i in data:
				os.remove(f)
			break
		h = hashlib.md5(data).hexdigest()
		shutil.move(f, './exps/'+h+'.txt')

