<?php
$secret =base64_encode($_GET['secret']);

require_once('config.php');
$sql = "SELECT username, message FROM `message` WHERE secret='{$secret}'";

/* Select queries return a resultset */
if ($result = mysqli_query($link, $sql)) {
    if($row = mysqli_fetch_row($result)){
        var_dump($row);
        $name = $row[0];
        $message = $row[1];
        ?>
<html>
<body>
    <script>var debug=false;</script>
    <div id="<?php echo $name; ?>">
        <h2><?php echo $name; ?></h2>
    </div>
    <div id="text"></div>
    <script>
    data = "<?php echo $message; ?>"
    t = document.getElementById("text")
    if(debug){
        t.innerHTML=data
    }else{
        t.innerText=data
    }
    </script>
</body>
</html>

<?php
    die();
    }
}
die('no such secret!');
?>


