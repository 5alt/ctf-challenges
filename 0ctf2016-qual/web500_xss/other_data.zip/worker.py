#!/usr/bin/env python
#coding=utf-8

import MySQLdb
import MySQLdb.cursors
import subprocess
from urllib import quote_plus
import base64
import time

host = 'localhost'
port = 3306
user = 'checker'
passwd = 'rMbMBpRQvBJhzNGj'
db = 'guestbook'

while True:
	try:
		conn = MySQLdb.connect(host=host, port=port, user=user, passwd=passwd, db=db, cursorclass = MySQLdb.cursors.DictCursor)
		cursor = conn.cursor()
		sql = 'SELECT * FROM `message` WHERE status=0'
		cursor.execute(sql)
		res = cursor.fetchall()
		if not res:
			raise Exception("All done. Sleeping..")
		for i in res:
			try:
				if i['username'] == 'debug':
					url = 'http://127.0.0.1:8888/admin/show.php?secret='+quote_plus(base64.b64decode(i['secret']))
					print url
					subprocess.Popen(["nohup", "phantomjs", "run.js", url])
			except Exception as e:
				print e
			sql = "UPDATE message SET status=1 WHERE secret=%s"
			cursor.execute(sql, [i['secret']])
			conn.commit()
	except Exception as e:
		print e
		pass
	finally:
		cursor.close()
		conn.close()
		time.sleep(3)


#subprocess.Popen(["nohup", "python", "test.py"])


