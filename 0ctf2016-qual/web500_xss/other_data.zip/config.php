<?php
$link = mysqli_connect("localhost", "guestbook", "8tsWy7cuBx5BV8qZ", "guestbook");
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}